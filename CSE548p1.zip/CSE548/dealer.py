"""
dealer.py  (Unix domain socket edition)
========================================
Multiplayer Texas Hold'em server with a live dealer console.

Usage:
    python3 dealer.py <num_players>

The dealer's terminal shows a live view that redraws on every event:
  • All player hole cards (face-up — the dealer sees everything)
  • Community cards on the board
  • Each player's balance and status (active / folded / bust)
  • A scrolling action + chat log
"""

import sys, os, time
sys.path.insert(0, '/home/dealer')

from cards   import Deck, Card
from banking import BankAccount
from poker_communication import (
    SOCKET_PATH,
    create_server_socket, authenticate, cleanup_conn,
    send_to, send_player, recv_from,
    async_recv, broadcast,
    init_dealer_log, log_hands, log_chat,
    render_cards, render_concealed, parse_card, parse_cards,
)

STARTING_BALANCE = 1000
SMALL_BLIND      = 10
BIG_BLIND        = 20
ACTION_TIMEOUT   = 30.0
LOG_LINES        = 12       # action log lines shown in console

HAND_NAMES = [
    'High Card', 'One Pair', 'Two Pair', 'Three of a Kind',
    'Straight', 'Flush', 'Full House', 'Four of a Kind', 'Straight Flush',
]

# ANSI helpers
RESET  = '\033[0m'
BOLD   = '\033[1m'
DIM    = '\033[2m'
RED    = '\033[31m'
GREEN  = '\033[32m'
YELLOW = '\033[33m'
CYAN   = '\033[36m'
WHITE  = '\033[37m'


# ── Dealer console ────────────────────────────────────────────────────────────
class DealerConsole:
    """
    Tracks game state and redraws the dealer's terminal on every event.

    The dealer can see:
      • Every player's hole cards (face-up, graphical ASCII art)
      • The community board cards
      • Each player's chip balance and active/folded status
      • A scrolling log of all actions and chat messages
    """

    def __init__(self):
        self.hand_num  = 0
        self.phase     = 'waiting'
        self.pot       = 0
        self.hands     = {}        # {player_id: [Card, Card]}
        self.community = []        # [Card, ...]
        self.balances  = {}        # {player_id: int}
        self.active    = []        # player_ids still in the hand
        self.all_pids  = []        # all players in the game
        self.log       = []        # [(phase, player_id_or_None, text)]

    # ── Logging ───────────────────────────────────────────────────────────
    def record(self, text, player=None):
        self.log.append((self.phase, player, text))
        self.redraw()

    def record_action(self, player, action):
        self.record(action, player=player)

    def record_chat(self, player, text):
        self.record('CHAT: %s' % text, player=player)

    # ── State setters ─────────────────────────────────────────────────────
    def new_hand(self, hand_num, players, balances):
        self.hand_num  = hand_num
        self.phase     = 'dealing'
        self.pot       = 0
        self.hands     = {}
        self.community = []
        self.active    = list(players)
        self.all_pids  = list(players)
        self.balances  = {p: balances[p].show_balance() for p in players}
        self.log       = []
        self.redraw()

    def set_hands(self, hands):
        self.hands = {p: list(c) for p, c in hands.items()}
        self.redraw()

    def set_community(self, cards):
        self.community = list(cards)
        self.redraw()

    def set_phase(self, phase, pot):
        self.phase = phase
        self.pot   = pot
        self.redraw()

    def player_folded(self, pid, balances):
        if pid in self.active:
            self.active.remove(pid)
        self.balances[pid] = balances[pid].show_balance()
        self.redraw()

    def update_balances(self, balances):
        for p in balances:
            self.balances[p] = balances[p].show_balance()
        self.redraw()

    # ── Drawing ───────────────────────────────────────────────────────────
    def redraw(self):
        W = 72   # console width
        out = []

        def line(text='', fill=' '):
            # Pad/truncate to W-4 (inside the border)
            inner = text[:W-4]
            pad   = W - 4 - len(inner)
            out.append('║ ' + inner + ' ' * pad + ' ║')

        def rule(char='═'):
            out.append('╠' + char * (W-2) + '╣')

        def top():
            out.append('╔' + '═' * (W-2) + '╗')

        def bot():
            out.append('╚' + '═' * (W-2) + '╝')

        # Header
        top()
        title = ('%sDEALER CONSOLE%s  ·  Hand #%d  ·  %s%s%s  ·  Pot: %d' % (
            BOLD, RESET, self.hand_num,
            YELLOW, self.phase.upper(), RESET,
            self.pot))
        # ANSI codes don't consume display width — adjust manually
        display_title = ('DEALER CONSOLE  ·  Hand #%d  ·  %s  ·  Pot: %d' % (
            self.hand_num, self.phase.upper(), self.pot))
        pad = W - 4 - len(display_title)
        out.append('║ ' + title + ' ' * pad + ' ║')

        # Player hands
        rule()
        line('%sPLAYER HANDS%s' % (BOLD, RESET))
        line()

        # Show up to 4 players per row
        pids = self.all_pids
        COLS = 2   # players per display row
        for row_start in range(0, len(pids), COLS):
            row_pids = pids[row_start:row_start + COLS]

            # Status lines
            status_parts = []
            for pid in row_pids:
                bal     = self.balances.get(pid, '?')
                is_act  = pid in self.active
                status  = ('%s[%d] $%-4s %s%s' % (
                    GREEN if is_act else DIM,
                    pid, bal,
                    'ACTIVE' if is_act else 'FOLDED',
                    RESET))
                display_status = ('[%d] $%-4s %s' % (
                    pid, bal, 'ACTIVE' if is_act else 'FOLDED'))
                # Pad to 30 chars of display width
                status_parts.append(status + ' ' * max(0, 30 - len(display_status)))
            line('  '.join(status_parts))

            # Gather card rows for this group of players
            card_rows_per_player = []
            for pid in row_pids:
                if pid in self.hands and self.hands[pid]:
                    rows = render_cards(self.hands[pid])
                else:
                    rows = render_concealed(2)
                card_rows_per_player.append(rows)

            # Print card rows side by side (5 rows per card block)
            for r in range(5):
                parts = []
                for card_rows in card_rows_per_player:
                    parts.append(card_rows[r] if r < len(card_rows) else '')
                line('  '.join(parts))
            line()

        # Community board
        rule()
        line('%sBOARD%s' % (BOLD, RESET))
        line()
        if self.community:
            for row in render_cards(self.community):
                line('  ' + row)
        else:
            line('  (no cards yet)')
        line()

        # Action log
        rule()
        line('%sACTIONS & MESSAGES%s' % (BOLD, RESET))
        recent = self.log[-LOG_LINES:]
        for (ph, pid, text) in recent:
            if pid is not None:
                entry = '[%s] P%d: %s' % (ph, pid, text)
            else:
                entry = '[%s] %s' % (ph, text)
            line('  ' + entry)
        # Pad to LOG_LINES rows so the box height stays stable
        for _ in range(LOG_LINES - len(recent)):
            line()

        bot()

        # Clear screen and print
        sys.stdout.write('\033[2J\033[H')
        sys.stdout.write('\n'.join(out) + '\n')
        sys.stdout.flush()


# ── Hand evaluation ───────────────────────────────────────────────────────────
def _card_value(rank):
    return {'Jack': 11, 'Queen': 12, 'King': 13, 'Ace': 14}.get(rank, int(rank))

def _score_five(cards):
    vals  = sorted([_card_value(c.rank) for c in cards], reverse=True)
    suits = [c.suit for c in cards]
    counts = {}
    for v in vals:
        counts[v] = counts.get(v, 0) + 1
    freq = sorted(counts.values(), reverse=True)
    is_flush = len(set(suits)) == 1
    sv = sorted(set(vals))
    is_straight = len(sv) == 5 and sv[-1] - sv[0] == 4
    if set(sv) == {14, 2, 3, 4, 5}:
        is_straight, vals = True, [5, 4, 3, 2, 1]
    if   is_straight and is_flush: return (8, vals)
    elif freq[0] == 4:             return (7, vals)
    elif freq[:2] == [3, 2]:       return (6, vals)
    elif is_flush:                 return (5, vals)
    elif is_straight:              return (4, vals)
    elif freq[0] == 3:             return (3, vals)
    elif freq[:2] == [2, 2]:       return (2, vals)
    elif freq[0] == 2:             return (1, vals)
    else:                          return (0, vals)

def evaluate_hand(hole, community):
    from itertools import combinations
    best = None
    for five in combinations(hole + community, 5):
        s = _score_five(list(five))
        if best is None or s > best:
            best = s
    return best


# ── Connection phase ──────────────────────────────────────────────────────────
def wait_for_players(srv, num_players, console):
    console.record('Waiting for %d players on %s' % (num_players, SOCKET_PATH))
    conn_map, pending = {}, []

    while len(conn_map) < num_players:
        watch = {c: None for c in pending}
        msgs, new_conns = async_recv(watch, server_sock=srv, timeout=2.0)

        for nc in new_conns:
            pending.append(nc)
            send_to(nc, 'IDENTIFY:Send READY:<player_id>')

        for conn in list(pending):
            for sender, body in recv_from(conn):
                if body.upper().startswith('READY:'):
                    try:
                        claimed_id = int(body.split(':', 1)[1])
                    except (ValueError, IndexError):
                        send_to(conn, 'ERROR:Use READY:<number>')
                        continue
                    if not authenticate(conn, claimed_id):
                        send_to(conn, 'ERROR:Auth failed for player%d' % claimed_id)
                        cleanup_conn(conn)
                        pending.remove(conn)
                        break
                    if claimed_id in conn_map.values():
                        send_to(conn, 'ERROR:Player %d already connected' % claimed_id)
                        cleanup_conn(conn)
                        pending.remove(conn)
                        break
                    conn_map[conn] = claimed_id
                    pending.remove(conn)
                    send_to(conn, 'WELCOME:Player %d — balance %d' % (
                        claimed_id, STARTING_BALANCE))
                    console.record('Player %d connected  (%d/%d)' % (
                        claimed_id, len(conn_map), num_players))
                    break

    return conn_map


# ── Betting round ─────────────────────────────────────────────────────────────
def betting_round(active_pids, conn_map, balances, pot, current_bets,
                  community, round_name, console):
    max_bet = max(current_bets.values()) if current_bets else BIG_BLIND
    to_act  = list(active_pids)

    active_map = {c: p for c, p in conn_map.items() if p in active_pids}
    broadcast('PHASE:%s' % round_name, active_map)
    broadcast('POT:%d'   % pot,        active_map)
    if community:
        broadcast('COMMUNITY:%s' % '|'.join(str(c) for c in community), active_map)
    for pid in active_pids:
        owed = max_bet - current_bets.get(pid, 0)
        send_player(pid, 'YOUR_TURN:to_call=%d balance=%d' % (
            owed, balances[pid].show_balance()), conn_map)

    console.set_phase(round_name, pot)
    if community:
        console.set_community(community)

    while to_act:
        msgs, _ = async_recv(active_map, timeout=ACTION_TIMEOUT)
        if not msgs:
            for p in list(to_act):
                active_pids.remove(p)
                to_act.remove(p)
                broadcast('INFO:Player %d timed out (auto-fold).' % p,
                          {c: pid for c, pid in conn_map.items()
                           if pid in active_pids})
                console.player_folded(p, balances)
                console.record_action(p, 'AUTO-FOLD (timeout)')
            break

        for player, body in msgs:
            if player not in to_act:
                continue
            upper = body.strip().upper()

            if upper == 'FOLD':
                to_act.remove(player)
                active_pids.remove(player)
                send_player(player, 'ACK:You folded.', conn_map)
                remain = {c: p for c, p in conn_map.items() if p in active_pids}
                broadcast('INFO:Player %d folded.' % player, remain)
                console.player_folded(player, balances)
                console.record_action(player, 'FOLD')

            elif upper == 'CALL':
                owed   = max_bet - current_bets.get(player, 0)
                amount = min(owed, balances[player].show_balance())
                balances[player].sub_balance(amount)
                pot += amount
                current_bets[player] = current_bets.get(player, 0) + amount
                to_act.remove(player)
                send_player(player, 'ACK:Called %d. Balance: %d' % (
                    amount, balances[player].show_balance()), conn_map)
                console.update_balances(balances)
                console.record_action(player, 'CALL $%d' % amount)

            elif upper.startswith('RAISE:'):
                try:
                    raise_by = int(body.strip().split(':', 1)[1])
                    assert raise_by > 0
                except (ValueError, IndexError, AssertionError):
                    send_player(player, 'ERROR:Use RAISE:<positive integer>', conn_map)
                    continue
                needed = (max_bet - current_bets.get(player, 0)) + raise_by
                if balances[player].show_balance() < needed:
                    send_player(player, 'ERROR:Need %d have %d' % (
                        needed, balances[player].show_balance()), conn_map)
                    continue
                balances[player].sub_balance(needed)
                pot    += needed
                max_bet += raise_by
                current_bets[player] = max_bet
                to_act.remove(player)
                for p in active_pids:
                    if p != player and p not in to_act:
                        to_act.append(p)
                send_player(player, 'ACK:Raised %d. Max=%d. Balance: %d' % (
                    raise_by, max_bet, balances[player].show_balance()), conn_map)
                remain = {c: p for c, p in conn_map.items() if p in active_pids}
                broadcast('INFO:Player %d raised to %d.' % (player, max_bet),
                          {c: p for c, p in remain.items() if p != player})
                console.update_balances(balances)
                console.record_action(player, 'RAISE $%d  (max=%d)' % (raise_by, max_bet))

            elif upper.startswith('CHAT:'):
                text = body.strip()[5:]
                log_chat(player, text)
                all_map = {c: p for c, p in conn_map.items() if p in active_pids}
                broadcast('CHAT:[P%d] %s' % (player, text), all_map)
                console.record_chat(player, text)

            else:
                send_player(player, 'ERROR:Unknown action. '
                            'FOLD / CALL / RAISE:<n> / CHAT:<text>', conn_map)

    console.set_phase(round_name, pot)
    return pot, active_pids


# ── Single hand ───────────────────────────────────────────────────────────────
def play_hand(players, conn_map, balances, deck, hand_num, console):
    deck.shuffle()
    console.new_hand(hand_num, players, balances)

    # Deal hole cards
    hands = {}
    for p in players:
        c1, c2 = deck.draw_card(), deck.draw_card()
        hands[p] = [c1, c2]
        send_player(p, 'HOLE:%s|%s' % (c1, c2), conn_map)

    log_hands(hands, hand_num)
    console.set_hands(hands)
    console.record('Hole cards dealt — see PLAYER HANDS above')

    # Blinds
    pot = 0
    current_bets = {p: 0 for p in players}
    if len(players) >= 2:
        sb, bb = players[0], players[1]
        balances[sb].sub_balance(SMALL_BLIND)
        balances[bb].sub_balance(BIG_BLIND)
        current_bets[sb] = SMALL_BLIND
        current_bets[bb] = BIG_BLIND
        pot = SMALL_BLIND + BIG_BLIND
        send_player(sb, 'INFO:You posted small blind (%d).' % SMALL_BLIND, conn_map)
        send_player(bb, 'INFO:You posted big blind (%d).'  % BIG_BLIND,   conn_map)
        console.record('Blinds: P%d=$%d  P%d=$%d  Pot=$%d' % (
            sb, SMALL_BLIND, bb, BIG_BLIND, pot))

    active = list(players)

    # Pre-flop
    pot, active = betting_round(active, conn_map, balances, pot,
                                dict(current_bets), [], 'pre-flop', console)
    if len(active) <= 1:
        return _end_hand(active, hands, [], balances, pot, conn_map, console)

    # Flop
    community = [deck.draw_card() for _ in range(3)]
    console.set_community(community)
    console.record('FLOP: %s' % '  '.join(str(c) for c in community))
    pot, active = betting_round(active, conn_map, balances, pot,
                                {p: 0 for p in active}, list(community),
                                'flop', console)
    if len(active) <= 1:
        return _end_hand(active, hands, community, balances, pot, conn_map, console)

    # Turn
    community.append(deck.draw_card())
    console.set_community(community)
    console.record('TURN:  %s' % str(community[-1]))
    pot, active = betting_round(active, conn_map, balances, pot,
                                {p: 0 for p in active}, list(community),
                                'turn', console)
    if len(active) <= 1:
        return _end_hand(active, hands, community, balances, pot, conn_map, console)

    # River
    community.append(deck.draw_card())
    console.set_community(community)
    console.record('RIVER: %s' % str(community[-1]))
    pot, active = betting_round(active, conn_map, balances, pot,
                                {p: 0 for p in active}, list(community),
                                'river', console)

    return _end_hand(active, hands, community, balances, pot, conn_map, console)


def _end_hand(active, hands, community, balances, pot, conn_map, console):
    all_pids = list(hands.keys())
    all_map  = {c: p for c, p in conn_map.items() if p in all_pids}

    if len(active) == 0:
        broadcast('INFO:No winner.', all_map)
        console.record('No winner (all folded simultaneously)')

    elif len(active) == 1:
        w = active[0]
        balances[w].add_balance(pot)
        msg = 'Player %d wins $%d (last standing).' % (w, pot)
        broadcast('WINNER:' + msg, all_map)
        console.update_balances(balances)
        console.record(msg)

    else:
        broadcast('SHOWDOWN:Revealing hands...', all_map)
        for p in active:
            h = hands[p]
            broadcast('SHOWDOWN:Player %d shows %s, %s' % (p, h[0], h[1]), all_map)
        best, winner = None, None
        for p in active:
            s = evaluate_hand(hands[p], community)
            if best is None or s > best:
                best, winner = s, p
        name = HAND_NAMES[best[0]] if best else '?'
        balances[winner].add_balance(pot)
        msg = 'Player %d wins $%d with %s!' % (winner, pot, name)
        broadcast('WINNER:' + msg, all_map)
        console.update_balances(balances)
        console.record('WINNER: ' + msg)

    return balances


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print('Usage: python3 dealer.py <num_players>')
        sys.exit(1)

    num_players = int(sys.argv[1])
    console = DealerConsole()
    console.record('Starting dealer — %d players  (%s)' % (num_players, SOCKET_PATH))

    init_dealer_log()

    srv      = create_server_socket()
    conn_map = wait_for_players(srv, num_players, console)
    players  = sorted(conn_map.values())
    balances = {p: BankAccount(STARTING_BALANCE) for p in players}

    all_map = dict(conn_map)
    broadcast('GAME_START:Game on! Starting balance: %d chips.' % STARTING_BALANCE,
              all_map)
    console.record('All players connected — game starting')

    deck     = Deck()
    hand_num = 0

    try:
        while True:
            active = [p for p in players if balances[p].show_balance() > 0]
            if len(active) < 2:
                msg = ('Player %d wins the game!' % active[0]
                       if active else 'No chips remain.')
                broadcast('GAME_OVER:' + msg, all_map)
                console.record('GAME OVER: ' + msg)
                break

            hand_num += 1
            broadcast('NEW_HAND:#%d — %d players active.' % (hand_num, len(active)),
                      all_map)
            for p in active:
                send_player(p, 'BALANCE:%d' % balances[p].show_balance(), conn_map)

            balances = play_hand(active, conn_map, balances, deck, hand_num, console)
            deck.reset_deck()
            time.sleep(2)
    finally:
        for conn in conn_map:
            cleanup_conn(conn)
        srv.close()
        try:
            os.unlink(SOCKET_PATH)
        except OSError:
            pass
        print('\n[dealer] Game over after %d hands.' % hand_num)


if __name__ == '__main__':
    main()
